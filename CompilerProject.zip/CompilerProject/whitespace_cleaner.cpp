/*
Final Project Part 1

This program reads a text file.
Program removes documentation and extra white space from the file
Program prints cleaned file
*/

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstring>

using namespace std;



//Function loads data from target text file and copies data into string vector
void load(string path, vector<string> &data) {
	string buffer;
	fstream fs;
	fs.open(path, fstream::in);
	if (fs.is_open()) {
		int i = 0;
		while (getline(fs, buffer)) {
			data.push_back(buffer);
		}
		fs.close();
	}
	else {
		cout << "ERROR: Failure To Open File" << endl;
		fs.close();
		exit(1);
	}
}

void write(string path, vector<string> data) {
	fstream fs;
	fs.open(path, fstream::out);
	if (fs.is_open()) {
		for (string buffer : data) {
			fs << buffer << endl;
		}
	}
	fs.close();
}

void trim(string &s) {
	while (s.size() && isspace(s.front()))
		s.erase(s.begin());
	while (s.size() && isspace(s.back()))
		s.pop_back();
}


int main(int argc, char* argv[]) {
	const string READ_PATH(argv[1]);
	const string WRITE_PATH(argv[2]);
	vector<string> data = {};

	//Load data into memory
	load(READ_PATH, data);

/*	Code for printing original data
	cout << "----------Original----------" << endl;
	for (string buffer : data) {
		cout << buffer << endl;
	}

	cout << endl << endl;
*/

	vector<string> output = {};
	bool isComment = false;


	for (int i = 0; i < data.size(); i++) {
		trim(data[i]);
		if (data[i].size() > 0) {
			const string cstr = data[i];
			string temp;


			for (int j = 0; j < cstr.length(); j++) {
				if (cstr[j] == '(' && cstr[j + 1] == '*') {
					isComment = true;
					j += 2;
				}
				else if (cstr[j] == '*' && cstr[j + 1] == ')') {
					isComment = false;
					j += 2;
				}
				else if (cstr[j] == ' ') {
					trim(temp);
					temp += cstr[j];
				}
				else if (!isComment) {
					if (cstr[j] == '+' | cstr[j] == '-'
						| cstr[j] == '*' | cstr[j] == '/'
						| cstr[j] == ')') {
						trim(temp);
						temp += ' ';
						temp += cstr[j];
					}
					else if (cstr[j] == '(' | cstr[j] == ',') {
						trim(temp);
						temp += cstr[j];
						temp += ' ';
					}
					else if (cstr[j] == '=' | cstr[j] == ':') {
						trim(temp);
						temp += ' ';
						temp += cstr[j];
						temp += ' ';
					}
					else if (cstr[j] == ';') {
						trim(temp);
						temp += cstr[j];
						break;
					}
					else {
						temp += cstr[j];
					}
				}
			}
			trim(temp);
			if (temp.size() > 0) {
				output.push_back(temp);
			}
		}
	}
	write(WRITE_PATH, output);
  //code for printing output to console
	//cout << "----------output----------" << endl;
	for (string buffer : output) {
		cout << buffer << endl;
	}
}
